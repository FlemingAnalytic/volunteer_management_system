<h1>Dialog</h1>
<div id="dialogcontent" name="dialogcontent">
	
</div>

<script>
$("#dialogcontent").innerHTML("<h3>This will work!</h3>")
</script>
