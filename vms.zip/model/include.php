<?php
$_server='localhost';
$_user='user';
$_pwd='pwd';
$_db='vms';

?>